# meteor-admin
Admin, generic templates for MeteorJS
